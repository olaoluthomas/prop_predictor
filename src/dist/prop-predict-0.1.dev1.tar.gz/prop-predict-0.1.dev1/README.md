---
# Model Serving for Main Event Propensity Models


Facilitating DM propensity model serving in Vertex AI.

---